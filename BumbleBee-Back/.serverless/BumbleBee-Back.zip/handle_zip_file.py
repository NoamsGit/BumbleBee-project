


def handle_zip_file(event, context):
    pass