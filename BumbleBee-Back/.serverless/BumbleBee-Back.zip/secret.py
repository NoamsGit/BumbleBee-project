
AWS_KEY = 'AKIAIAXXTOSL34MXBMPQ'
AWS_SECRET_KEY = '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'
MONGODB_URL = 'mongodb+srv://node-rest-shop:node-rest-shop@node-rest-shop.qy06n.mongodb.net/test?retryWrites=true&w=majority'
